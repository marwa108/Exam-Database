use OnlineExam

alter proc exam_correction @exam_id int , @st_id int
as
if not exists(select st_id, exam_id from st_answer
 where exam_id=@exam_id and st_id=@st_id) 
select 'Student or Exam ID not exist'
else
begin
declare @grade int = 0 
if (select st_ans1 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans1 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans2 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans2 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans3 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans3 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans4 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans4 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans5 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans5 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans6 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans6 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans7 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans7 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans8 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans8 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans9 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans9 from exam where exam_id=@exam_id )
set @grade =@grade+1

if (select st_ans10 from st_answer where exam_id=@exam_id and st_id=@st_id)=
(select ans10 from exam where exam_id=@exam_id )
set @grade =@grade+1

declare @topic_id int

select @topic_id=topic_id  from exam e , topic_exam t
where e.exam_id=t.exam_id and  e.exam_id=@exam_id 

insert into st_crs
values (@st_id,@topic_id, @grade)

end


exam_correction 6,3


exam_correction 2,1