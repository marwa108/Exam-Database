use OnlineExam

alter proc Generate_Exam
@topic_name varchar(50) , @mcq_n int , @TF_n int
as
if @mcq_n+@TF_n=10
begin
	declare @n int
	declare @mcq_temp table (num int,id int)
	declare @tf_temp table (num int,id int)
	declare @num int
	select @num=1
	declare @num1 int
	select @num1=1
	select @n=0

	while @n<@mcq_n
	begin
		declare @val int

		select @val=(select top 1 mcq_num from mcq inner join topic on topic.topic_id=mcq.topic_id and topic.topic_name=@topic_name
		order by newid())
		if @val not in (select id from @mcq_temp )
		begin
			insert @mcq_temp(num,id) values(@num,@val)
			select @n=@n+1
			select @num=@num+1
		end
	end

	declare @n1 int
	select @n1=0
	while @n1<@tf_n
	begin
		declare @val1 int

		select @val1=(select top 1 tf_num from true_false as tf inner join topic on topic.topic_id=tf.topic_id and topic.topic_name=@topic_name
		
		order by newid())
		if @val1 not in (select id from @tf_temp )
		begin
			insert @tf_temp(num,id) values(@num1,@val1)
			select @n1=@n1+1
			select @num1=@num1+1
		end
	end



	declare @final_t table (num int identity(1,1),id int,q varchar(max),ans varchar(max))


	insert into @final_t(id,q,ans)
	select t.id , tf.tf_q ,tf.tf_ans from @tf_temp as t inner join true_false as tf 
	on t.id=tf.tf_num


	insert into @final_t(id,q,ans)
	select t.id , mcq.mcq_q ,mcq.mcq_ans from @mcq_temp as t inner join mcq 
	on t.id=mcq.mcq_num


	declare @temp1 varchar(max)
	declare @temp2 varchar(max)
	declare @temp3 varchar(max)
	declare @temp4 varchar(max)
	declare @temp5 varchar(max)
	declare @temp6 varchar(max)
	declare @temp7 varchar(max)
	declare @temp8 varchar(max)
	declare @temp9 varchar(max)
	declare @temp10 varchar(max)

	declare @ans1 varchar(max)
	declare @ans2 varchar(max)
	declare @ans3 varchar(max)
	declare @ans4 varchar(max)
	declare @ans5 varchar(max)
	declare @ans6 varchar(max)
	declare @ans7 varchar(max)
	declare @ans8 varchar(max)
	declare @ans9 varchar(max)
	declare @ans10 varchar(max)

	select @temp1=q from @final_t where num=1
	select @temp2=q from @final_t where num=2
	select @temp3=q from @final_t where num=3
	select @temp4=q from @final_t where num=4
	select @temp5=q from @final_t where num=5
	select @temp6=q from @final_t where num=6
	select @temp7=q from @final_t where num=7
	select @temp8=q from @final_t where num=8
	select @temp9=q from @final_t where num=9
	select @temp10=q from @final_t where num=10

	select @ans1=ans from @final_t where num=1
	select @ans2=ans from @final_t where num=2
	select @ans3=ans from @final_t where num=3
	select @ans4=ans from @final_t where num=4
	select @ans5=ans from @final_t where num=5
	select @ans6=ans from @final_t where num=6
	select @ans7=ans from @final_t where num=7
	select @ans8=ans from @final_t where num=8
	select @ans9=ans from @final_t where num=9
	select @ans10=ans from @final_t where num=10

	declare @ins_id int
	select @ins_id=teaches.ins_id from teaches inner join  topic on topic.topic_id=teaches.topic_id and topic_name=@topic_name


	insert into exam (ins_id,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,ans1,ans2,ans3,ans4,ans5,ans6,ans7,ans8,ans9,ans10)
	values(@ins_id,@temp1,@temp2,@temp3,@temp4,@temp5,@temp6,@temp7,@temp8,@temp9,@temp10,@ans1,@ans2,@ans3,@ans4,@ans5,@ans6,@ans7,@ans8,@ans9,@ans10)

	insert into topic_exam(topic_id)
	select topic_id from topic where topic_name=@topic_name
end

else
begin
	PRINT 'number of questions must equal 10'
end


Generate_Exam 'c programming',7,3

