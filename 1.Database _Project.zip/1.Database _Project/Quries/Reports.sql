create proc student_information_in_department @dep_num int
as
if exists (select * from student where dept_id=@dep_num)
begin
select * from student
where dept_id=@dep_num
end
else
select 'department number not exists'


student_information_in_department 1
----------------------------------------------------------------------

alter proc student_grades @st_id int
as
if exists (select * from st_crs where st_id=@st_id)
begin
 select st_fname+' '+st_lname , topic_name,grade from student, st_crs s ,topic t,topic_exam te
 where s.st_id=@st_id and  s.st_id=student.st_id and s.topic_id=te.topic_id and t.topic_id=te.topic_id
 end
 else if not exists(select * from student where st_id=@st_id)
 begin
 select 'student not exists' as error
 end
else
 select 'student do not have grades' as error

 student_grades 1
 --------------------------------------------------------------------------
 alter proc ins_cources @ins_id int
 as
 if exists (select * from instructor where ins_id=@ins_id)
 begin
 if  not exists (select * from teaches
 where  ins_id=@ins_id)
 begin
 select 'instructor do not have cources'
 end
 else
 select ins_name, topic_name ,count(st_id) as number_of_student
 from topic c, st_crs s,teaches i ,instructor ins
 where c.topic_id=i.topic_id and c.topic_id=s.topic_id and i.ins_id=@ins_id and i.ins_id=ins.ins_id
 group by topic_name , ins_name
 end
 else 
 select 'instructor id not exists'

 ins_cources 1
 ------------------------------------------------------------------
 alter proc crs_topic @crs_id int
 as
 if exists(select * from course where crs_id=@crs_id)
 begin
 if not exists(select * from topic where crs_id=@crs_id)
 begin
 select 'do not have topics'
 end
 else
 select crs_name ,topic_name from topic t, course c
 where c.crs_id=@crs_id and c.crs_id=t.crs_id
 end
 else 
 select ' cource id do not exists'

 crs_topic 3

 ------------------------------------------------------------------------------

 alter proc student_exam_answer @exam_num int,@st_id int
 as
 if exists(select exam_id , st_id from st_answer where exam_id=@exam_num and st_id=@st_id)
 begin
  
 select st_fname+st_lname,topic_name, q1 as questions , st_ans1 as answers
 from exam e , st_answer s ,student ss ,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q2 , st_ans2
 from exam e , st_answer s, student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q3 , st_ans3
 from exam e , st_answer s , student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q4 , st_ans4
 from exam e , st_answer s,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q5 , st_ans5
 from exam e , st_answer s,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q6 , st_ans6
 from exam e , st_answer s,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q7 , st_ans7
 from exam e , st_answer s ,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q8 , st_ans8
 from exam e , st_answer s ,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q9 , st_ans9
 from exam e , st_answer s ,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 union all
 select st_fname+st_lname,topic_name,q10 , st_ans10
 from exam e , st_answer s ,student ss,topic t, topic_exam te
 where e.exam_id=s.exam_id and e.exam_id=@exam_num and s.st_id=@st_id and s.st_id=ss.st_id
 and e.exam_id=te.exam_id and t.topic_id=te.topic_id
 end
 else
 select 'not found'

 student_exam_answer 5,1
 ----------------------------------------------------------------------------------------
 alter proc exam_qustions @exam_num int
 as
 select topic_name, q1 ,q2 ,q3 ,q4 ,
 q5 ,q6,q7 ,
 q8 ,q9 ,q10 
 from exam e ,topic ,topic_exam te
 where e.exam_id = @exam_num and e.exam_id=te.exam_id and topic.topic_id=te.topic_id

  exam_qustions 5
  