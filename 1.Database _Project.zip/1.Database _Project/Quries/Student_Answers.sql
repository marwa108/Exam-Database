use OnlineExam

create proc Student_Answers @exam_id int , @st_id int, @a1 varchar(2),@a2 varchar(2),@a3 varchar(2) ,@a4 varchar(2),
@a5 varchar(2),@a6 varchar(2),@a7 varchar(2),@a8 varchar(2),@a9 varchar(2),@a10 varchar(2)
as
if not exists(select exam_id from exam where exam_id=@exam_id)
select 'exam id not exist'
else if not exists(select st_id from student where st_id=@st_id)
select ' student id not exist'
else 
begin
	insert into st_answer(exam_id,st_id,st_ans1,st_ans2,st_ans3,st_ans4,st_ans5,st_ans6,st_ans7,st_ans8,st_ans9,st_ans10)
	values(@exam_id , @st_id , @a1 ,@a2 ,@a3 ,@a4 ,@a5 ,@a6 ,@a7 ,@a8 ,@a9, @a10)
end


student_answers 2,1,'a','a','d','c','f','d','c','b','f','g'