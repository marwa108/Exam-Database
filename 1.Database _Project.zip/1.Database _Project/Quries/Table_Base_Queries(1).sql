-- Basic Procedures For First 6 Tables.
-- Course Table

create procedure Select_From_Course
as
select * from course
return
----------------------
create procedure Insert_Into_Course
(@Course_ID int,@Course_Name varchar(50),@Course_Duration int)
as
if not exists(select crs_ID  from course where crs_ID=@Course_ID)
insert into course values(@Course_ID,@Course_Name,@Course_Duration)
else
print 'Course ID is already exists!'
return
-----------------------
create procedure Delete_From_Course(@ID int)
as
if exists (select crs_id from course where crs_id = @ID)
delete from course 
where crs_id = @ID
else 
print 'Course ID is not found'
return
-----------------------
create procedure Update_In_Course
(@Course_ID int,@Course_Name varchar(50),@Course_Duration int)
as
if exists (select crs_ID from course where crs_id = @Course_ID)
update course set crs_name = @Course_Name ,crs_duration = @Course_Duration
where crs_id = @Course_ID
else 
print 'Course ID not Found!'
return
-----------------------
-- Department Table

create procedure Select_From_Department
as
select * from Department
return
------------------------
create procedure Insert_Into_Department
(@Depart_ID int, @Depart_Name varchar(50), @Manager_Date date)
as
if not exists (select dept_id from department where dept_id = @Depart_ID)
insert into department values(@Depart_ID,@Depart_Name,@Manager_Date)
else
print 'Department ID is already exists'
return
-------------------------
create procedure Delete_From_Department (@Depart_ID int)
as
if exists (select dept_id from department where dept_id = @Depart_ID)
delete from department
where dept_id = @Depart_ID
else 
print 'Department ID not found!'
return
-------------------------
create procedure Update_In_Department
(@Depart_ID int, @Depart_Name varchar(50), @Manager_Date date)
as
if exists (select dept_id from department where dept_id = @Depart_ID)
update department set dept_name = @Depart_Name,manager_hiredate = @Manager_Date
where dept_id = @Depart_ID 
else 
print 'Department ID not found!'
return
--------------------------
-- Exam Table
create procedure Select_From_Exam
as
select * from exam
return
--------------------------
create procedure Insert_Into_Exam
(@ExamID int, @INSID int, @Question1 int, @Question2 int,@Question3 int,@Question4 int,@Question5 int,@Question6 int,
@Question7 int,@Question8 int,@Question9 int,@Question10 int, @MODEL_ANSWER_Q1 int,@MODEL_ANSWER_Q2 int,@MODEL_ANSWER_Q3 int,
@MODEL_ANSWER_Q4 int,@MODEL_ANSWER_Q5 int,@MODEL_ANSWER_Q6 int,@MODEL_ANSWER_Q7 int,@MODEL_ANSWER_Q8 int,
@MODEL_ANSWER_Q9 int,@MODEL_ANSWER_Q10 int)
as
if not exists (select exam_id from exam where exam_id = @ExamID)
begin
if exists (select ins_id from instructor where ins_id = @INSID)
insert into exam values (@ExamID, @INSID,@Question1,@Question2,@Question3,@Question4,@Question5,@Question6,
@Question7,@Question8,@Question9,@Question10,@MODEL_ANSWER_Q1,@MODEL_ANSWER_Q2,@MODEL_ANSWER_Q3,
@MODEL_ANSWER_Q4,@MODEL_ANSWER_Q5,@MODEL_ANSWER_Q6,@MODEL_ANSWER_Q7,@MODEL_ANSWER_Q8,
@MODEL_ANSWER_Q9,@MODEL_ANSWER_Q10)
else 
print 'Instructor Not Found'  
end
else
print 'Exam ID is already exists!'
return
----------------------------
create procedure Delete_From_Exam(@EXAMID int)
as
if exists (select exam_id from exam where exam_id = @ExamID)
delete from exam where exam_id = @ExamID
else 
print 'Exam ID is not found!'
return
----------------------------
create procedure Update_In_Exam
(@ExamID int, @INSID int, @Question1 int, @Question2 int,@Question3 int,@Question4 int,@Question5 int,@Question6 int,
@Question7 int,@Question8 int,@Question9 int,@Question10 int, @MODEL_ANSWER_Q1 int,@MODEL_ANSWER_Q2 int,@MODEL_ANSWER_Q3 int,
@MODEL_ANSWER_Q4 int,@MODEL_ANSWER_Q5 int,@MODEL_ANSWER_Q6 int,@MODEL_ANSWER_Q7 int,@MODEL_ANSWER_Q8 int,
@MODEL_ANSWER_Q9 int,@MODEL_ANSWER_Q10 int)
as
if exists (select exam_id from exam where exam_id = @ExamID)
update exam set ins_id = @INSID, q1 = @Question1,q2 = @Question2,q3 = @Question3,q4 = @Question4,
q5 = @Question5,q6 = @Question6,q7 = @Question7,q8 = @Question8,q9 = @Question9,q10 = @Question10,ans1 = @MODEL_ANSWER_Q1,
ans2 = @MODEL_ANSWER_Q2,ans3 = @MODEL_ANSWER_Q3,ans4 = @MODEL_ANSWER_Q4,ans5 = @MODEL_ANSWER_Q5,ans6 = @MODEL_ANSWER_Q6,
ans7 = @MODEL_ANSWER_Q7,ans8 = @MODEL_ANSWER_Q8,ans9 = @MODEL_ANSWER_Q9,ans10 = @MODEL_ANSWER_Q10
where exam_id = @ExamID
else 
print 'Exam ID is not found!'
return
----------------------------------
-- Instructor Table 

create procedure Select_From_Instructor
as 
select * from instructor
return
----------------------------------
create procedure Insert_Into_Instructor(@INSID int,@INSNAME varchar(50),@INSSALARY int,@DepartmentID int)
as
if not exists(select ins_id from instructor where ins_id = @INSID)
insert into instructor values(@INSID,@INSNAME,@INSSALARY,@DepartmentID)
else
print 'Instructor id is already found'
return
----------------------------------
create procedure Delete_From_Instructor(@INSID int)
as
if exists (select ins_id from instructor where ins_id = @INSID)
delete from instructor where ins_id = @INSID
else 
print 'Instructor id is not found'
return
----------------------------------
create procedure Update_In_Instructor(@INSID int,@INSNAME varchar(50),@INSSALARY int,@DepartmentID int)
as
if exists (select ins_id from instructor where ins_id = @INSID)
update instructor set ins_name = @INSNAME, ins_salary = @INSSALARY, dept_id = @DepartmentID
where ins_id = @INSID 
else 
print 'Instructor id is not found'
return
----------------------------------------------------------------------------------------------



