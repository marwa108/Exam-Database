use OnlineExam

alter proc Insert_In_mcq 
 @q nvarchar(max) ,@ans nvarchar(max),@CrsId int
as
insert into mcq values (@q,@ans,@CrsId)
return
---------------------
create proc Select_From_mcq
as
select * from mcq
return
-----------------------
alter proc Update_mcq
@num int , @q nvarchar(max) ,@ans nvarchar(max),@CrsId int
as
if exists(select mcq_num from mcq where mcq_num=@num)
	update mcq
	set mcq_num=@num , mcq_q=@q , mcq_ans=@ans , crs_id=@CrsId
	where mcq_num=@num
else 
	select 'question does not exists'
return
------------------------
create proc Delete_From_mcq
@num int 
as
if exists(select mcq_num from mcq where mcq_num=@num)
	delete from mcq where mcq_num=@num
else
select 'question does not exists'
return
---------------------------------------------
-- Table St_Answer
create procedure Select_From_St_Answer
as
select * from st_answer
return
------------------------
create procedure Insert_Into_St_Answer(@STID int, @ST_ANS1 varchar(MAX),@ST_ANS2 varchar(MAX),@ST_ANS3 varchar(MAX),
@ST_ANS4 varchar(MAX),@ST_ANS5 varchar(MAX),@ST_ANS6 varchar(MAX),@ST_ANS7 varchar(MAX),@ST_ANS8 varchar(MAX),@ST_ANS9 varchar(MAX),
@ST_ANS10 varchar(MAX))
as
insert into St_answer values(@STID,@ST_ANS1,@ST_ANS2,@ST_ANS3,@ST_ANS4,@ST_ANS5,@ST_ANS6,@ST_ANS7,@ST_ANS8,@ST_ANS9,@ST_ANS10)
return
-------------------------
create procedure Delete_From_St_Answer(@EXAMID int, @STID int)
as
if exists (select exam_id,st_id from st_answer)
delete from st_answer where exam_id = @EXAMID and st_id = @STID 
else
print 'Exam ID is not found or student not found'
return
-------------------------
create procedure Update_In_St_Answer(@EXAMID int, @STID int, @ST_ANS1 varchar(MAX),@ST_ANS2 varchar(MAX),@ST_ANS3 varchar(MAX),
@ST_ANS4 varchar(MAX),@ST_ANS5 varchar(MAX),@ST_ANS6 varchar(MAX),@ST_ANS7 varchar(MAX),@ST_ANS8 varchar(MAX),@ST_ANS9 varchar(MAX),
@ST_ANS10 varchar(MAX))
as
if exists (select exam_id,st_id from st_answer)
update st_answer set st_id = @STID st_ans1 = @ST_ANS1,st_ans2 = @ST_ANS2,st_ans3 = @ST_ANS3,st_ans4 = @ST_ANS4,st_ans5 = @ST_ANS5,
st_ans6 = @ST_ANS6,st_ans7 = @ST_ANS7,st_ans8 = @ST_ANS8,st_ans9 = @ST_ANS9,st_ans10 = @ST_ANS10
else
print 'Exam or student ID is not found!' 
return
---------------------------------------------------------------------------
-- Table St_crs
create procedure Select_From_St_crs
as
select * from st_answer
return
------------------------------------
create procedure Delete_From_St_Crs(@STID int,@TOPICID int,@GRADE int)
as
if exists(select st_id,topic_id from st_crs)
delete from st_crs where st_id = @STID and topic_id = @TOPICID
else
print 'Student or topic is not found!'
-----------------------------------------------------------------------------
-- Table St_Answer
create procedure Select_From_Student
as
select * from student
return
----------------------------
create procedure Insert_Into_Student(@ST_FNAME varchar(50), @ST_LNAME varchar(50), @ST_ADD nchar(10),@ST_AGE int,@DEPT_ID int)
as
insert into student values(@ST_FNAME,@ST_LNAME,@ST_ADD,@ST_AGE,@DEPT_ID)
return
----------------------------
create procedure Delete_From_Student(@ST_ID int ,@ST_FNAME varchar(50), @ST_LNAME varchar(50), @ST_ADD nchar(10),@ST_AGE int,@DEPT_ID int)
as
if exists(select st_id from student)
delete from student where st_id = @ST_ID
else
print 'Student is not found!'
----------------------------
create procedure Update_In_Student(@ST_ID int ,@ST_FNAME varchar(50), @ST_LNAME varchar(50), @ST_ADD nchar(10),@ST_AGE int,@DEPT_ID int)
as
if exists(select st_id from student)
update student set st_id = @ST_ID, st_fname = @ST_FNAME,st_lname = @ST_LNAME,st_address = @ST_ADD,st_age=@ST_AGE,dept_id = @DEPT_ID)
else
print 'student ID is not found!' 
return
--------------------------
create procedure Select_From_Teaches
as
select * from teaches
return
--------------------------
create procedure Insert_Into_Teaches(@INS_ID int, @TOPIC_ID int)
as
insert into student values(@INS_ID,@TOPIC_ID)
return
--------------------------
create procedure Delete_From_Teaches(@INS_ID int, @TOPIC_ID int)
as
if exists(select ins_id,topic_id from teaches)
delete from teaches where ins_id = @INS_ID and topic_id=@TOPIC_ID
else
print 'Topic or Instructor is not found!'
--------------------------
create procedure Update_In_Teaches(@INS_ID int, @TOPIC_ID int)
as
if exists(select ins_id,topic_id from teaches)
update teaches set ins_id = @INS_ID ,topic_id = @TOPIC_ID
else
print 'Topic or Instructor is not found!' 
return