------------------------------Basic Procedures For Last 5 Tables---------------------------------------

-- Topic Table

create procedure Select_From_Topic
as
select * from topic
return
----------------------
create procedure Insert_Into_Topic
(@Topic_ID int,@Topic_Name varchar(50),@Course_ID int)
as
insert into topic values(@Topic_ID,@Topic_Name,@Course_ID)
return
-----------------------
create procedure Delete_From_Topic(@Topic_ID int)
as
delete from topic 
where topic_id = @Topic_ID
return
-----------------------
create procedure Update_In_Topic
(@Topic_ID int,@Topic_Name varchar(50),@Course_ID int)
as
update topic set topic_name = @Topic_Name 
where topic_id = @Topic_ID
return
-------------------------------------------------------------------

-- Table Topic_Exam

create procedure Select_From_Topic_Exam
as
select * from topic_exam
return
----------------------
create procedure Insert_Into_Topic_Exam
(@Topic_ID int,@Exam_ID int)
as
insert into topic_exam values(@Topic_ID,@Exam_ID)
return
-----------------------
create procedure Delete_From_Topic_Exam(@TopicID int)
as
delete from topic_exam 
where topic_id = @TopicID
return
-----------------------
create procedure Update_In_Topic_Exam
(@Topic_ID int,@Exam_ID int)
as
update topic_exam set exam_id = @Exam_ID 
where topic_id = @Topic_ID
return
-------------------------------------------------------------------

-- Table True_False

create procedure Select_From_True_False
as
select * from true_false
return
----------------------
create procedure Insert_Into_True_False
(@TF_Number int,@TF_Questions varchar(max),@TF_Answers varchar(50),@Course_ID int)
as
insert into true_false values(@TF_Number,@TF_Questions,@TF_Answers,@Course_ID int)
return
-----------------------
create procedure Delete_From_True_False(@TF_Number int)
as
delete from true_false
where tf_num = @TF_Number
return
-----------------------
create procedure Update_In_True_False
(@TF_Number int,@TF_Questions varchar(max),@TF_Answers varchar(50),@Course_ID int)
as
update true_false set tf_q = @TF_Questions , tf_ans = @TF_Answers
where tf_num = @TF_Number
return
-------------------------------------------------------------------


-- Table Work

create procedure Select_From_Work
as
select * from work
return
-------------------------------
create procedure Insert_Into_Work(@Depart_ID int,@INSID int)
as
insert into work values (@Depart_ID,@INSID)
return
--------------------------------
create procedure Delete_From_Work(@Depart_ID int)
as
delete from work where dept_id = @Depart_ID
return
---------------------------------
create procedure Update_In_Work(@Depart_ID int,@INSID int)
as
update work set ins_id = @INSID where dept_id = @Depart_ID
return
-------------------------------------------------------------------------------------------